const express = require('express');
const bodyParser = require('body-parser');
const router = express.Router();
const ds = require('../lib/datastore');

const datastore = ds.datastore;

const CARGO = "Cargo";
const BOAT = "Boat";

router.use(bodyParser.json());

/* ------------- Begin guest Model Functions ------------- */
function post_cargo(weight, content, delivery_date){
    var key = datastore.key(CARGO);
	const new_cargo = {"weight": weight, "content": content, "delivery_date": delivery_date};
	return datastore.save({"key": key, "data": new_cargo}).then(() => {return key});
}

// async function get_all_cargo(req) {
    // const c_key = datastore.key([CARGO, parseInt(sid, 10)]);
    // const new_date = (new Date()).toString();
	
    // const query = datastore.createQuery(CARGO).filter('id', '=', sid);
    // const result = await datastore.runQuery(query);

    // const slip_num = result[0].number;
    // const updated_slip = {"number": slip_num, "current_boat": bid, "arrival_date": new_date};
    // return datastore.update({"key": s_key, "data": updated_slip});
// }

async function get_all_cargo(req){
    var q = datastore.createQuery(CARGO).limit(3);
    const results = {};
    var prev;
    if(Object.keys(req.query).includes("cursor")){
        console.log(req.query);
        q = q.start(req.query.cursor);
    }
	// return datastore.runQuery(q)
		return datastore.runQuery(q)

	.then( (entities) => {
		console.log(entities);
		results.cargo = entities[0].map(ds.fromDatastore);
		results.cargo.forEach((result) => {
			if (typeof(result.carrier) !== 'undefined') {
				const b_key = datastore.key([BOAT, parseInt(result.carrier.id, 10)]);
				// return datastore.get(b_key)
				con
				.then( (boat) => {
					if(boat[0] !== 'undefined'){
						// carrier.id = boat[0].id;
						result.carrier.name = boat[0].name;
					}
					
					// result.id = id;
					// result.self = req.protocol + "://" + req.get("host") + "/boats/" + id;
					
					return result;		
				});

				
				// var boatQuery = datastore.createQuery(BOAT).filter('id', result.carrier.id);
				// return datastore.runQuery(boatQuery)
				// .then((boatInfo) => {
					// console.log("boatInfo: " + boatInfo);
					// var cargoCarrier = {};
					// result.carrier = boatInfo[0].map(ds.fromDatastore);
					// cargoCarrier.id = boatInfo[0].id;
					// cargoCarrier.name = boatInfo[0].name;
					// result.carrier = cargoCarrier;
					// return result;
				// });
				// result.carrier.name = await datastore.get(datastore.key([BOAT, parseInt(result.carrier.id)]));
				result.carrier.self = req.protocol + "://" + req.get("host") + "/boats/" + result.carrier.id;
			}
			
			result.self = req.protocol + "://" + req.get("host") + "/cargo/" + result.id;
		});
		if(entities[1].moreResults !== ds.Datastore.NO_MORE_RESULTS ){
			results.next = req.protocol + "://" + req.get("host") + req.baseUrl + "?cursor=" + entities[1].endCursor;
		}
		return results;
	});
}

function get_cargo(req, id) {
	var result = {};
	const c_key = datastore.key([CARGO, parseInt(id, 10)]);
    return datastore.get(c_key)
    .then( (cargo) => {
        if( typeof(cargo[0].carrier) !== 'undefined'){
			result = cargo[0];
            var boat = [];
			result.carrier.id
			result.carrier.forEach((item) => {
				var cargoCarrier = {};
				cargoCarrier.id = item;
				cargoCarrier.self = req.protocol + "://" + req.get("host") + "/boat/" + item;
				boat.push(cargoCarrier);
			});
			
			result.carrier = boat;
        }
		
		result.id = id;
		result.self = req.protocol + "://" + req.get("host") + "/cargo/" + id;
		
		return result;		
    });
}

// ??
function put_guest(id, name){
    const key = datastore.key([CARGO, parseInt(id, 10)]);
    const cargo = {"name": name};
    return datastore.save({"key":key, "data":cargo});
}

function delete_cargo(id){
    const key = datastore.key([CARGO, parseInt(id, 10)]);
    return datastore.delete(key);
}

/* ------------- End Model Functions ------------- */

/* ------------- Begin Controller Functions ------------- */

router.get('/', function(req, res){
    const cargo = get_all_cargo(req)
	.then( (cargo) => {
        res.status(200).json(cargo);
    })
});

router.get('/:id', function(req, res){
    const cargo = get_cargo(req, req.params.id)
	.then( (cargo) => {
		res.status(200).json(cargo);
    });
});

router.post('/', function(req, res){
    console.log(req.body);
    post_cargo(req.body.weight, req.body.content, req.body.delivery_date)
    .then( key => {res.status(200).send('{ "id": ' + key.id + ' }')} );
});

router.put('/:id', function(req, res){
    put_guest(req.params.id, req.body.name)
    .then(res.status(200).end());
});

router.delete('/:id', function(req, res){
    delete_cargo(req.params.id).then(res.status(200).end())
});

/* ------------- End Controller Functions ------------- */

module.exports = router;